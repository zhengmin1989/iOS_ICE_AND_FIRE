#import <CaptainHook/CaptainHook.h>

CHDeclareClass(Talker);


CHMethod(1, void, Talker, say, id, arg1)
{
    NSString* tmp=@"Hello, Android!";
    
    CHSuper(1, Talker, say, tmp);
}


__attribute__((constructor)) static void entry()
{
    NSLog(@"Hello, Ice And Fire!");
    CHLoadLateClass(Talker);
    CHClassHook(1, Talker,say);
}
